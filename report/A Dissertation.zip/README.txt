Download this file into your personal device. 

For use on LaTeX on local device, unzip the file and open the project using your local LaTeX compilation tool (e.g. MiKTeX). 

For use on Overleaf, upload the .zip file to your overleaf account through:
1. Sign in to your overleaf account
2. New Project -- Upload Project
3. Upload this .zip file onto overleaf. 

Most of the preambles are in the main.tex file. Add any preambles if necessary, but the current packages should be sufficient for normal use. 

Under the main.tex file, you can choose two different versions of your title page, under line 48 and 49 (or right after \begin{document}). Likewise, there are two different abstract style and you can choose which looks nicer too. Right before that, fill in your information to ensure the title page contains the necessary information is there on the title page. 

To edit the content of the document, go into the respective .tex files, located in each of the folders. The folders are arranged according to the order of appearance in the document. You can add more files/folders to the project for more chapters. My personal suggestion is to also include the images in each chapter in the folder instead of outside the folder so that it will look neater too. 